# Radni sati — Android projekat

Tamna Android aplikacija za Samsung Galaxy A56.

## Funkcije
- Kalendar mjeseca sa izborom dana
- Unos početka i kraja smjene
- Smjene koje prelaze ponoć
- Automatsko razdvajanje dnevnog rada i noćnog rada (22:00–06:00)
- Čuvanje podataka lokalno na telefonu
- Mjesečni zbir dnevnih, noćnih i ukupnih sati

## Izrada APK-a
Otvoriti folder `RadniSati` u Android Studio, sačekati Gradle Sync, pa izabrati **Build > Build APK(s)**. APK se obično nalazi u `app/build/outputs/apk/debug/app-debug.apk`.

Napomena: projekat zahtijeva Android SDK Platform 34 i kompatibilan Android Gradle Plugin. Ovaj paket sadrži izvorni projekat; APK nije ugrađen u ZIP.
